import AppKit
import ServiceManagement

/// UserDefaults-backed app settings. UI panes read/write these; backend
/// behaviors observe them. Keys are stable — don't rename.
@MainActor
enum VNSettings {
    private static let d = UserDefaults.standard

    // MARK: Sound

    static var soundEnabled: Bool {
        get { d.object(forKey: "soundEnabled") as? Bool ?? true }
        set { d.set(newValue, forKey: "soundEnabled") }
    }

    /// 0…1 output gain for synthesized alerts.
    static var soundVolume: Double {
        get { d.object(forKey: "soundVolume") as? Double ?? 0.7 }
        set { d.set(newValue, forKey: "soundVolume") }
    }

    // MARK: Behavior

    /// Seconds before an unanswered permission escalates (repeat chime +
    /// ⚠ menu-bar badge). 0 disables.
    static var escalationSeconds: Int {
        get { d.object(forKey: "escalationSeconds") as? Int ?? 120 }
        set { d.set(newValue, forKey: "escalationSeconds") }
    }

    /// Auto-approve safe-listed simple commands (git status, ls, …).
    static var safeListEnabled: Bool {
        get { d.object(forKey: "safeListEnabled") as? Bool ?? false }
        set { d.set(newValue, forKey: "safeListEnabled") }
    }

    /// Hide the compact notch entirely when no sessions are active.
    /// Don't auto-pop approval cards while the agent's own terminal is
    /// frontmost — you're already looking at the prompt there.
    static var smartSuppression: Bool {
        get { d.object(forKey: "smartSuppression") as? Bool ?? true }
        set { d.set(newValue, forKey: "smartSuppression") }
    }

    /// Hide the notch entirely when no agent is working/waiting (keeps it off
    /// fullscreen video). On by default.
    static var autoHideWhenIdle: Bool {
        get { d.object(forKey: "autoHideWhenIdle") as? Bool ?? false }
        set { d.set(newValue, forKey: "autoHideWhenIdle") }
    }

    /// Which permissions the notch intercepts: "low" = all (default),
    /// "medium" = medium+high only, "high" = high only. Below the threshold
    /// the agent's own terminal prompt handles it.
    static var notchMinRisk: String {
        get { d.string(forKey: "notchMinRisk") ?? "low" }
        set { d.set(newValue, forKey: "notchMinRisk") }
    }

    /// Undo window after a decision, seconds (0 = decisions are instant).
    static var undoSeconds: Int {
        get { d.object(forKey: "undoSeconds") as? Int ?? 0 } // 0 = commit instantly (undo opt-in)
        set { d.set(newValue, forKey: "undoSeconds") }
    }

    /// YOLO mode: auto-approve everything until this epoch timestamp.
    static var yoloUntil: Double {
        get { d.double(forKey: "yoloUntil") }
        set { d.set(newValue, forKey: "yoloUntil") }
    }

    /// Alert sound theme: chime | arcade | minimal.
    static var soundTheme: String {
        get { d.string(forKey: "soundTheme") ?? "chime" }
        set { d.set(newValue, forKey: "soundTheme") }
    }

    /// Also hold cards while a macOS Focus mode is on.
    static var focusGuard: Bool {
        get { d.bool(forKey: "focusGuard") }
        set { d.set(newValue, forKey: "focusGuard") }
    }

    /// Hold approval cards while the screen is being shared.
    static var screenShareGuard: Bool {
        get { d.object(forKey: "screenShareGuard") as? Bool ?? true }
        set { d.set(newValue, forKey: "screenShareGuard") }
    }

    /// ntfy.sh topic for phone escalation pings. Empty = off (default).
    static var ntfyTopic: String {
        get { d.string(forKey: "ntfyTopic") ?? "" }
        set { d.set(newValue, forKey: "ntfyTopic") }
    }

    /// Localhost web dashboard (0 = off).
    static var dashboardPort: Int {
        get {
            let value = d.integer(forKey: "dashboardPort")
            return (1...65535).contains(value) ? value : 0
        }
        set { d.set((1...65535).contains(newValue) ? newValue : 0, forKey: "dashboardPort") }
    }

    /// Labs: keep the notch above the lock screen / fullscreen (private API).
    static var lockScreenNotch: Bool {
        get { d.bool(forKey: "lockScreenNotch") }
        set { d.set(newValue, forKey: "lockScreenNotch") }
    }

    // MARK: Integrations

    /// Wire newly detected agents automatically on launch. Off means the app
    /// never touches an agent config you didn't connect yourself.
    static var autoConfigureAgents: Bool {
        get { d.object(forKey: "autoConfigureAgents") as? Bool ?? true }
        set { d.set(newValue, forKey: "autoConfigureAgents") }
    }

    /// First-run window has been dismissed. Until it is, Vibe Notch touches
    /// no agent config — the window's Connect button is the yes.
    static var welcomeSeen: Bool {
        get { d.bool(forKey: "welcomeSeen") }
        set { d.set(newValue, forKey: "welcomeSeen") }
    }

    // MARK: Display

    /// Which screen owns the notch. Empty = the main display.
    static var notchDisplayID: String {
        get { d.string(forKey: "notchDisplayID") ?? "" }
        set { d.set(newValue, forKey: "notchDisplayID") }
    }

    /// How long a hover-only expansion stays open before collapsing itself.
    static var dwellSeconds: Double {
        get { let v = d.double(forKey: "dwellSeconds"); return v <= 0 ? 5 : v }
        set { d.set(newValue, forKey: "dwellSeconds") }
    }

    /// Panel type scale, 0.8…1.6. Everything in the notch scales together.
    static var contentScale: Double {
        get { let v = d.double(forKey: "contentScale"); return v <= 0 ? 1 : v }
        set { d.set(newValue, forKey: "contentScale") }
    }

    /// How wide the expanded panel is, in points.
    static var panelWidth: Int {
        get { let v = d.integer(forKey: "panelWidth"); return v <= 0 ? 620 : v }
        set { d.set(newValue, forKey: "panelWidth") }
    }

    /// Leave room for the notch shape's margins even on scaled/external displays.
    static var notchScreen: NSScreen? {
        NSScreen.screens.first { $0.vnDisplayID == notchDisplayID }
            ?? NSScreen.screens.first { $0.safeAreaInsets.top > 0 } ?? NSScreen.main
    }

    static var effectivePanelWidth: CGFloat {
        min(CGFloat(panelWidth), max(280, (notchScreen?.frame.width ?? 1710) - 100))
    }

    /// Collapse a hover-opened panel when the pointer leaves. Off keeps it up
    /// until Esc or a click elsewhere.
    static var collapseOnLeave: Bool {
        get { d.object(forKey: "collapseOnLeave") as? Bool ?? true }
        set { d.set(newValue, forKey: "collapseOnLeave") }
    }

    // MARK: Shortcuts

    /// Master switch for every keyboard shortcut, mappings kept.
    static var shortcutsEnabled: Bool {
        get { d.object(forKey: "shortcutsEnabled") as? Bool ?? true }
        set { d.set(newValue, forKey: "shortcutsEnabled") }
    }

    // MARK: Usage

    /// Show the provider usage chips in the expanded panel header.
    static var showUsageLimits: Bool {
        get { d.object(forKey: "showUsageLimits") as? Bool ?? true }
        set { d.set(newValue, forKey: "showUsageLimits") }
    }

    // MARK: Launch at login (SMAppService)

    static var launchAtLogin: Bool {
        get { SMAppService.mainApp.status == .enabled }
        set {
            do {
                if newValue { try SMAppService.mainApp.register() }
                else { try SMAppService.mainApp.unregister() }
            } catch {
                NSLog("VibeNotch: launch-at-login failed: \(error)")
            }
        }
    }
}
