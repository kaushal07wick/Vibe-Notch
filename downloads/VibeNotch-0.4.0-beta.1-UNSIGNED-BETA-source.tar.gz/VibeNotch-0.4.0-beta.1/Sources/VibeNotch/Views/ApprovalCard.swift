import SwiftUI
import VibeNotchCore

/// The permission card: folder · task, You-line, tool warning, boxed command,
/// and the four decision buttons.
struct ApprovalCard: View {
    let approval: PendingApproval
    @ObservedObject var store: EventStore
    let queued: Int
    private var i: VNInbound { approval.inbound }

    /// Plan-review mode: `ExitPlanMode` carries the Markdown plan for approval.
    private var isPlanReview: Bool { i.tool == "ExitPlanMode" && i.plan != nil }

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            header
            if let questions = i.questions, !questions.isEmpty {
                QuestionPrompt(questions: questions) { store.answer(approval, answers: $0) }
            } else if isPlanReview, let plan = i.plan {
                planLine
                planBlock(plan)
                planButtons
            } else {
                toolLine
                if i.diffOld != nil || i.diffNew != nil {
                    diffBlock
                } else {
                    commandBlock
                }
                buttons
            }
            if queued > 0 {
                HStack(spacing: 14) {
                    Text("Show all \(queued + 1) sessions")
                        .font(VNFont.ui(11)).foregroundStyle(VNColor.faint)
                    Button { store.approveAll() } label: {
                        Text("Approve all \(queued + 1)")
                            .font(VNFont.ui(11, .semibold)).foregroundStyle(VNColor.go)
                    }
                    .buttonStyle(PressFeedback())
                }
                .frame(maxWidth: .infinity, alignment: .center).padding(.top, 1)
            }
        }
        .padding(EdgeInsets(top: 4, leading: 20, bottom: 10, trailing: 20))
        .frame(width: VNSettings.effectivePanelWidth)
        .background(riskTint, in: RoundedRectangle(cornerRadius: 14, style: .continuous))
        .padding(.horizontal, 4)
    }

    /// High risk earns a red cast, medium a faint amber one, low nothing.
    private var riskTint: Color {
        switch risk {
        case .high: VNColor.stop.opacity(0.07)
        case .medium: VNColor.amber.opacity(0.035)
        case .low: .clear
        }
    }

    private var header: some View {
        HStack(alignment: .center, spacing: 10) {
            AgentIcon(source: i.source, size: 22)
            VStack(alignment: .leading, spacing: 2) {
                HStack(spacing: 6) {
                    // "?" belongs on the line it qualifies, not floating off
                    // the mascot's shoulder.
                    PixelGlyph(grid: PixelGlyph.question, color: VNColor.amber, px: 2)
                    Text(sessionTitle(folder: (i.cwd as NSString?)?.lastPathComponent, task: i.title))
                        .font(VNFont.ui(13, .semibold)).lineLimit(1).truncationMode(.tail)
                }
                if let user = i.userMessage {
                    Text("You: \(user)").font(VNFont.ui(11)).foregroundStyle(VNColor.muted)
                        .lineLimit(1).truncationMode(.tail)
                }
            }
            Spacer(minLength: 8)
            PillCluster(source: i.source, terminal: i.terminal, tty: i.tty, meta: i.termMeta ?? [:])
        }
    }

    private var toolLine: some View {
        let tint = risk == .high ? VNColor.stop : VNColor.amber
        return HStack(spacing: 6) {
            Image(systemName: "exclamationmark.triangle.fill").font(VNFont.ui(9)).foregroundStyle(tint)
            Text(i.tool ?? "Tool").font(VNFont.ui(11.5, .semibold)).foregroundStyle(tint)
            if risk == .high {
                Text("HIGH RISK").font(VNFont.sysMono(9, .semibold)).tracking(0.8)
                    .foregroundStyle(VNColor.stop)
                    .padding(.horizontal, 5).padding(.vertical, 1.5)
                    .background(VNColor.stop.opacity(0.14), in: Capsule())
            }
            Spacer(minLength: 0)
        }
    }

    /// VI card: the FULL command up to `maxLines`, then a dim "+N lines"
    /// marker, with the description at the bottom of the same box.
    private var commandBlock: some View {
        let maxLines = 12
        let all = (i.detail ?? "").components(separatedBy: "\n")
        let shown = all.prefix(maxLines).joined(separator: "\n")
        let overflow = all.count - maxLines
        return VStack(alignment: .leading, spacing: 6) {
            (Text("$ ").foregroundStyle(VNColor.amber) + Text(shown).foregroundStyle(VNColor.paper.opacity(0.82)))
                .font(VNFont.uiMono(11.5, .semibold))
                // newline count alone isn't enough: one 3000-char line wraps to 40 rows and
                // pushes Deny/Allow off the panel. Cap what is *drawn*.
                .lineLimit(10).truncationMode(.tail)
                .fixedSize(horizontal: false, vertical: true)
                .frame(maxWidth: .infinity, alignment: .leading)
            if overflow > 0 {
                Text("+\(overflow) lines").font(VNFont.ui(10.5, .medium))
                    .foregroundStyle(VNColor.paper.opacity(0.35))
            }
            if let desc = i.commandDescription {
                Text(desc).font(VNFont.ui(11, .medium))
                    .foregroundStyle(VNColor.paper.opacity(0.5)).lineLimit(1)
            }
        }
        .padding(.horizontal, 12).padding(.vertical, 10)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(Color.white.opacity(0.045), in: RoundedRectangle(cornerRadius: 9, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: 9, style: .continuous).strokeBorder(Color.white.opacity(0.06)))
    }

    private var risk: Risk { RiskGrader.grade(tool: i.tool, detail: i.detail) }

    private var buttons: some View {
        VStack(spacing: 8) {
            // the agent's own "don't ask again" choices, applied by the agent itself
            if let picks = i.suggestions, !picks.isEmpty {
                HStack(spacing: 8) {
                    ForEach(Array(picks.prefix(2).enumerated()), id: \.offset) { _, pick in
                        WideButton(title: pick.label, kind: .always) { store.resolve(approval, .allow, permissions: [pick.json]) }
                    }
                }
            }
            HStack(spacing: 8) {
                WideButton(title: "Deny", kind: .deny) { store.resolve(approval, .deny) }
                WideButton(title: "Allow Once", kind: .primary, hint: "^A") { store.resolve(approval, .allow) }
                // no agent suggestion: the app persists the rule itself (PermissionRules);
                // not offered for remote sessions, which the store refuses anyway
                if i.suggestions?.isEmpty ?? true, i.host == nil {
                    WideButton(title: "Always Allow", kind: .always) { store.resolve(approval, .alwaysAllow) }
                }
                WideButton(title: "Bypass", kind: .danger) { store.resolve(approval, .bypass) }
            }
        }
    }

    /// Edit/Write approvals as a diff card: file header with +/- counts, then full-width tinted rows.
    private var diffBlock: some View {
        let old = (i.diffOld ?? "").isEmpty ? [] : (i.diffOld ?? "").components(separatedBy: "\n")
        let new = (i.diffNew ?? "").isEmpty ? [] : (i.diffNew ?? "").components(separatedBy: "\n")
        let isNewFile = old.isEmpty
        let cap = isNewFile ? 14 : 7
        return VStack(alignment: .leading, spacing: 0) {
            HStack(spacing: 7) {
                Image(systemName: isNewFile ? "doc.badge.plus" : "doc.text").font(VNFont.ui(10.5))
                    .foregroundStyle(VNColor.paper.opacity(0.55))
                Text(shortPath(i.detail)).font(VNFont.uiMono(11, .semibold))
                    .foregroundStyle(VNColor.paper.opacity(0.85)).lineLimit(1).truncationMode(.head)
                Spacer(minLength: 8)
                if !new.isEmpty { countChip("+\(new.count)", VNColor.go) }
                if !old.isEmpty { countChip("−\(old.count)", VNColor.stop) }
            }
            .padding(.horizontal, 12).padding(.vertical, 7)
            .background(Color.white.opacity(0.04))
            VStack(alignment: .leading, spacing: 0) {
                diffRows(old, sign: "−", color: VNColor.stop, cap: cap)
                diffRows(new, sign: "+", color: VNColor.go, cap: cap)
            }
            .padding(.vertical, 3)
            if let desc = i.commandDescription {
                Text(desc).font(VNFont.ui(11, .medium))
                    .foregroundStyle(VNColor.paper.opacity(0.5)).lineLimit(1)
                    .padding(.horizontal, 12).padding(.vertical, 6)
            }
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(Color.black.opacity(0.35))
        .clipShape(RoundedRectangle(cornerRadius: 10, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: 10, style: .continuous).strokeBorder(Color.white.opacity(0.08)))
    }

    private func countChip(_ text: String, _ color: Color) -> some View {
        Text(text).font(VNFont.sysMono(10, .semibold)).foregroundStyle(color)
            .padding(.horizontal, 6).padding(.vertical, 1.5)
            .background(color.opacity(0.14), in: Capsule())
    }

    private func shortPath(_ path: String?) -> String {
        guard let path, !path.isEmpty else { return i.tool ?? "file" }
        let parts = path.split(separator: "/")
        return parts.suffix(2).joined(separator: "/")
    }

    private func diffRows(_ lines: [String], sign: String, color: Color, cap: Int) -> some View {
        VStack(alignment: .leading, spacing: 0) {
            ForEach(Array(lines.prefix(cap).enumerated()), id: \.offset) { _, line in
                HStack(alignment: .top, spacing: 8) {
                    Text(sign).font(VNFont.uiMono(11, .bold)).foregroundStyle(color.opacity(0.9)).frame(width: 10)
                    Text(line.isEmpty ? " " : line).font(VNFont.uiMono(11, .medium))
                        .foregroundStyle(VNColor.paper.opacity(0.88)).lineLimit(1).truncationMode(.tail)
                    Spacer(minLength: 0)
                }
                .padding(.horizontal, 12).padding(.vertical, 1.5)
                .frame(maxWidth: .infinity, alignment: .leading)
                .background(color.opacity(0.13))
            }
            if lines.count > cap {
                Text("\(sign) \(lines.count - cap) more line\(lines.count - cap == 1 ? "" : "s")")
                    .font(VNFont.ui(10)).foregroundStyle(color.opacity(0.6))
                    .padding(.horizontal, 12).padding(.vertical, 3)
            }
        }
    }

    // MARK: Plan review

    private var planLine: some View {
        HStack(spacing: 6) {
            Image(systemName: "doc.text").font(VNFont.ui(10)).foregroundStyle(VNColor.running)
            Text("Plan ready for review").font(VNFont.ui(12.5, .semibold)).foregroundStyle(VNColor.running)
            Spacer(minLength: 0)
        }
    }

    private func planBlock(_ plan: String) -> some View {
        ScrollView {
            Text(planAttributed(plan))
                .font(VNFont.ui(11.5))
                .foregroundStyle(VNColor.text.opacity(0.92))
                .frame(maxWidth: .infinity, alignment: .leading)
                .padding(10)
                .textSelection(.enabled)
        }
        .scrollIndicators(.hidden)
        .frame(maxHeight: 230)
        .background(VNColor.ink2, in: RoundedRectangle(cornerRadius: 9))
        .overlay(RoundedRectangle(cornerRadius: 9).strokeBorder(VNColor.hair))
    }

    /// Markdown → AttributedString; falls back to plain text if parsing fails.
    private func planAttributed(_ plan: String) -> AttributedString {
        (try? AttributedString(
            markdown: plan,
            options: .init(allowsExtendedAttributes: false,
                           interpretedSyntax: .inlineOnlyPreservingWhitespace)
        )) ?? AttributedString(plan)
    }

    private var planButtons: some View {
        HStack(spacing: 8) {
            WideButton(title: "Keep planning", kind: .deny) { store.resolve(approval, .deny) }
            WideButton(title: "Approve plan", kind: .primary) { store.resolve(approval, .allow) }
        }
    }
}

/// White pill that fills red while held — releases the approval at 100%.

// MARK: - AskUserQuestion

/// Renders agent questions with tappable options. Single question, single
/// select → tapping answers immediately (VI's "Tap to select"). Otherwise
/// selections accumulate and an Answer button submits one label per question.
private struct QuestionPrompt: View {
    let questions: [VNQuestion]
    let submit: ([String]) -> Void
    @State private var picked: [Int: Set<String>] = [:]
    @State private var typed: [Int: String] = [:]

    private var instant: Bool { questions.count == 1 && !questions[0].multiSelect }
    private func answer(_ i: Int) -> String {
        var parts = (picked[i] ?? []).sorted()
        if let t = typed[i]?.trimmingCharacters(in: .whitespaces), !t.isEmpty { parts.append(t) }
        return parts.joined(separator: ", ")
    }
    private var complete: Bool { (0..<questions.count).allSatisfy { !answer($0).isEmpty } }

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            ScrollView {
                VStack(alignment: .leading, spacing: 12) {
                    ForEach(Array(questions.enumerated()), id: \.offset) { qi, q in
                        VStack(alignment: .leading, spacing: 5) {
                            HStack(alignment: .firstTextBaseline, spacing: 6) {
                                if questions.count > 1 {
                                    Text("\(qi + 1)/\(questions.count)")
                                        .font(VNFont.sysMono(9.5, .semibold))
                                        .foregroundStyle(VNColor.faint)
                                }
                                Text(q.question)
                                    .font(VNFont.ui(12, .semibold))
                                    .foregroundStyle(VNColor.paper.opacity(0.86))
                                    .fixedSize(horizontal: false, vertical: true)
                            }
                            ForEach(q.options, id: \.label) { opt in
                                optionRow(qi: qi, q: q, opt: opt)
                            }
                            otherField(qi)
                        }
                    }
                }
                .padding(.trailing, 2)
            }
            // Cap it and let it scroll — the Answer button has to stay reachable.
            .scrollIndicators(.hidden)
            .frame(maxHeight: 300)
            .fixedSize(horizontal: false, vertical: true)
            if !instant || !(typed[0] ?? "").isEmpty {
                WideButton(title: "Answer", kind: .primary) {
                    submit(questions.indices.map(answer))
                }
                .disabled(!complete)
                .opacity(complete ? 1 : 0.4)
            }
        }
    }

    /// Free-text "something else" — the answer when none of the options fit.
    private func otherField(_ qi: Int) -> some View {
        TextField("Something else…", text: Binding(get: { typed[qi] ?? "" }, set: { typed[qi] = $0 }))
            .textFieldStyle(.plain).font(VNFont.ui(11.8))
            .padding(.horizontal, 9).padding(.vertical, 6)
            .background(Color.white.opacity(0.035), in: RoundedRectangle(cornerRadius: 7, style: .continuous))
            .overlay(RoundedRectangle(cornerRadius: 7, style: .continuous).strokeBorder(Color.white.opacity(0.05)))
            .onSubmit { if complete { submit(questions.indices.map(answer)) } }
    }

    private func optionRow(qi: Int, q: VNQuestion, opt: VNQuestion.Option) -> some View {
        let isOn = picked[qi]?.contains(opt.label) ?? false
        return Button {
            if instant { submit([opt.label]); return }
            var set = picked[qi] ?? []
            if q.multiSelect {
                if isOn { set.remove(opt.label) } else { set.insert(opt.label) }
            } else {
                set = [opt.label]
            }
            picked[qi] = set
        } label: {
            HStack(alignment: .top, spacing: 8) {
                Text("⌘\(q.options.firstIndex(where: { $0.label == opt.label }).map { $0 + 1 } ?? 0)")
                    .font(VNFont.sysMono(9.5, .semibold))
                    .foregroundStyle(isOn ? VNColor.invader : VNColor.faint)
                    .frame(width: 24, height: 18)
                    .background(Color.white.opacity(isOn ? 0.12 : 0.06), in: RoundedRectangle(cornerRadius: 5, style: .continuous))
                VStack(alignment: .leading, spacing: 1) {
                    Text(opt.label).font(VNFont.ui(11.8, .medium)).foregroundStyle(VNColor.text)
                    if let d = opt.description, !d.isEmpty {
                        Text(d).font(VNFont.ui(10.5)).foregroundStyle(VNColor.muted)
                            .lineLimit(2).truncationMode(.tail).fixedSize(horizontal: false, vertical: true)
                    }
                }
                Spacer(minLength: 0)
            }
            .padding(.horizontal, 9).padding(.vertical, 6)
            .contentShape(Rectangle())
        }
        .buttonStyle(.plain)
        .cmdDigit((q.options.firstIndex(where: { $0.label == opt.label }) ?? 0) + 1)
        .background(Color.white.opacity(isOn ? 0.07 : 0.035), in: RoundedRectangle(cornerRadius: 7, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: 7, style: .continuous)
            .strokeBorder(isOn ? VNColor.invader.opacity(0.5) : Color.white.opacity(0.05)))
    }
}

/// Codex's own multiple-choice prompt, mirrored: pick a numbered option and the number is
/// typed into Codex's terminal (what you'd otherwise do with the arrow keys).
struct CodexQuestionCard: View {
    @ObservedObject var store: EventStore
    let question: CodexQuestion
    @State private var other = ""

    private var step: Int { min(store.codexQuestionStep, question.items.count - 1) }
    private var item: CodexQuestion.Item { question.items[step] }

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack(spacing: 8) {
                AgentIcon(source: "codex", size: 18)
                Text("Codex is asking").font(VNFont.ui(12.5, .semibold)).foregroundStyle(VNColor.running)
                if question.items.count > 1 {
                    Text("\(step + 1) of \(question.items.count)").font(VNFont.sysMono(10, .semibold))
                        .foregroundStyle(VNColor.faint)
                }
                Spacer(minLength: 8)
                Button { store.hideCodexQuestion(question) } label: {
                    Image(systemName: "xmark").font(.system(size: 9, weight: .semibold))
                        .foregroundStyle(VNColor.muted).frame(width: 20, height: 20)
                        .background(Color.white.opacity(0.07), in: Circle())
                }
                .buttonStyle(.plain).help("Hide — answer in the terminal instead")
            }
            Text(item.title).font(VNFont.ui(12)).foregroundStyle(VNColor.running)
                .fixedSize(horizontal: false, vertical: true)
            ScrollView {
                VStack(spacing: 5) {
                    ForEach(Array(item.options.enumerated()), id: \.offset) { i, option in
                        row(number: i + 1, label: option) { store.answerCodex(question, option: i) }
                    }
                    HStack(spacing: 8) {
                        Text("\(item.options.count + 1)").font(VNFont.sysMono(11, .semibold)).foregroundStyle(VNColor.faint)
                        TextField(item.options.isEmpty ? "Your answer…" : "Other…", text: $other).textFieldStyle(.plain).font(VNFont.ui(11.8))
                            .onSubmit { send(other) }
                        if !other.isEmpty {
                            Button("Send") { send(other) }.buttonStyle(.plain)
                                .font(VNFont.ui(11, .semibold)).foregroundStyle(VNColor.running)
                        }
                    }
                    .padding(.horizontal, 10).padding(.vertical, 7)
                    .background(Color.white.opacity(0.035), in: RoundedRectangle(cornerRadius: 7, style: .continuous))
                }
            }
            .scrollIndicators(.hidden).frame(maxHeight: 260).fixedSize(horizontal: false, vertical: true)
            if let error = store.codexAnswerError {
                Text(error).font(VNFont.ui(11)).foregroundStyle(VNColor.stop)
                    .fixedSize(horizontal: false, vertical: true)
            }
            if store.sendingCodexAnswer {
                Text("Sending to Codex…").font(VNFont.ui(11)).foregroundStyle(VNColor.muted)
            }
        }
        .disabled(store.sendingCodexAnswer)
        .onChange(of: item.index) { _, _ in other = "" }
        .onChange(of: question.id) { _, _ in other = "" }
        .padding(EdgeInsets(top: 4, leading: 20, bottom: 12, trailing: 20))
        .frame(width: VNSettings.effectivePanelWidth, alignment: .leading)
    }

    private func send(_ text: String) {
        let t = text.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !t.isEmpty else { return }
        store.answerCodex(question, option: item.options.count, text: t)
    }

    private func row(number: Int, label: String, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            HStack(spacing: 8) {
                Text("\(number)").font(VNFont.sysMono(11, .semibold)).foregroundStyle(VNColor.running)
                Text(label).font(VNFont.ui(11.8, .medium)).foregroundStyle(VNColor.text)
                    .multilineTextAlignment(.leading)
                Spacer(minLength: 0)
            }
            .padding(.horizontal, 10).padding(.vertical, 7)
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(Color.white.opacity(0.06), in: RoundedRectangle(cornerRadius: 7, style: .continuous))
            .contentShape(Rectangle())
        }
        .buttonStyle(PressFeedback())
    }
}

private extension View {
    /// ⌘1…⌘9 pick the matching option; later options simply have no shortcut.
    @ViewBuilder func cmdDigit(_ n: Int) -> some View {
        if (1...9).contains(n) { keyboardShortcut(KeyEquivalent(Character(String(n))), modifiers: .command) } else { self }
    }
}
